# Informe de Ciberinteligencia — 2026-07-29 (UTC)

**TLP:CLEAR**

## 1. Cabecera

- **Fecha (UTC):** 2026-07-29 22:43:36
- **Modo del informe:** línea base
- **Motivo de la línea base:** `estado_ausente`
- **Línea base anterior:** no consta ninguna anterior
- **Intervalo real:** indefinido (un censo no cubre un periodo).
- **Fuentes consultadas:** `cisa-kev` (correcta), `threatfox` (parcial)

### Cálculos no publicados en esta ejecución

- **No se publican** los indicadores nuevos, los caídos ni los reaparecidos: este informe es una línea base, un retrato de situación, y esos tres cálculos se definen por comparación con una ejecución anterior.
- **No se publica** la tabla de técnicas inferidas: su denominador son las entradas KEV nuevas del periodo, y un censo no tiene periodo.

## 2. BLUF

**1 vulnerabilidad explotada activamente tiene fecha límite de corrección en los próximos 7 días.** Es lo accionable de este informe; el detalle está en la sección 4.

Se han observado **7368 indicadores** en `cisa-kev` y **89 familias de malware**.

**Este informe es un retrato de situación, no un parte de novedades:** publica el censo
del panorama observado en la ventana de recolección declarada, y no informa de cambios
respecto a ninguna ejecución anterior, porque no hay una con la que comparar.

## 3. Juicios clave

No se emiten juicios en esta ejecución: los insumos disponibles no sostienen ninguna afirmación con confianza declarable.

## 4. Vulnerabilidades explotadas activamente (vigentes en el catálogo)

Se publican **20 de 1656** entradas, ordenadas por valor de decisión: primero las de uso conocido en campañas de ransomware, después las de fecha límite más próxima.

El uso conocido en campañas de ransomware lo declara CISA. Las de plazo dentro de los próximos 7 días van marcadas con ⏰.

| CVE | Fabricante | Producto | Uso en ransomware | Fecha límite |
|---|---|---|---|---|
| `CVE-2021-1675` | Microsoft | Windows | Known | 2021-11-17 |
| `CVE-2021-1732` | Microsoft | Win32k | Known | 2021-11-17 |
| `CVE-2021-20016` | SonicWall | SSLVPN SMA100 | Known | 2021-11-17 |
| `CVE-2021-20021` | SonicWall | SonicWall Email Security | Known | 2021-11-17 |
| `CVE-2021-20022` | SonicWall | SonicWall Email Security | Known | 2021-11-17 |
| `CVE-2021-20023` | SonicWall | SonicWall Email Security | Known | 2021-11-17 |
| `CVE-2021-21972` | VMware | vCenter Server | Known | 2021-11-17 |
| `CVE-2021-21985` | VMware | vCenter Server | Known | 2021-11-17 |
| `CVE-2021-22005` | VMware | vCenter Server | Known | 2021-11-17 |
| `CVE-2021-22205` | GitLab | Community and Enterprise Editions | Known | 2021-11-17 |
| `CVE-2021-22986` | F5 | BIG-IP and BIG-IQ Centralized Management | Known | 2021-11-17 |
| `CVE-2021-26084` | Atlassian | Confluence Server and Data Center | Known | 2021-11-17 |
| `CVE-2021-26411` | Microsoft | Internet Explorer | Known | 2021-11-17 |
| `CVE-2021-27101` | Accellion | FTA | Known | 2021-11-17 |
| `CVE-2021-27102` | Accellion | FTA | Known | 2021-11-17 |
| `CVE-2021-27103` | Accellion | FTA | Known | 2021-11-17 |
| `CVE-2021-27104` | Accellion | FTA | Known | 2021-11-17 |
| `CVE-2021-30116` | Kaseya | Virtual System/Server Administrator (VSA) | Known | 2021-11-17 |
| `CVE-2021-31207` | Microsoft | Exchange Server | Known | 2021-11-17 |
| `CVE-2021-34473` | Microsoft | Exchange Server | Known | 2021-11-17 |

## 5. Panorama de amenazas

De las **89 familias observadas**, 22 tienen entrada en ATT&CK. Los porcentajes no suman 100: una familia emplea varias técnicas.

## 6. Indicadores destacados

Infraestructura observada de mayor confianza, con los valores **defanged** para evitar clics accidentales. Las vulnerabilidades no figuran aquí: tienen su propia sección, con producto, plazo y uso en ransomware. Los indicadores sin mapeo ATT&CK compiten en igualdad: el enriquecimiento es enriquecimiento, no una puerta de calidad.

| Indicador | Tipo | Fuente | Confianza | Familia | Técnicas |
|---|---|---|---|---|---|
| `amberalcove[.]top` | `domain-name` | `threatfox` | 100 | SmartApeSG | — |
| `shpu1xz9[.]gdcpemasaranbekasi[.]com` | `domain-name` | `threatfox` | 100 | ClearFake | — |
| `www[.]hygroscopiccycle[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `jennifer-campbell[.]co[.]uk` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `pjeobx[.]jadoou[.]lat` | `domain-name` | `threatfox` | 100 | ClearFake | — |
| `endormo[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `lasnegrascamps[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `strang-02-static[.]com` | `domain-name` | `threatfox` | 100 | PureLogs Stealer | — |
| `172[.]232[.]240[.]110` | `ipv4-addr` | `threatfox` | 100 | Jackskid | — |
| `www[.]smibert[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `www[.]vertuoseclub[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `85[.]137[.]240[.]26` | `ipv4-addr` | `threatfox` | 100 | Unknown malware | — |
| `implexions[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |
| `ufpykr[.]rossbridgemedicalcenterlp[.]com` | `domain-name` | `threatfox` | 100 | ClearFake | — |
| `xn--b6bel7a3an0g[.]com` | `domain-name` | `threatfox` | 100 | IClickFix | — |

## 7. Recomendaciones y ventanas de decisión

1. **Priorizar el parcheo** de la entrada KEV con plazo en los próximos 7 días: `CVE-2026-60137` (2026-08-04).
2. **Revisar la recolección** de `threatfox`: no alcanzó estado `correcta`, y mientras dure, su parte del panorama y de la evolución no se publica. Plazo: antes de la siguiente ejecución diaria.

## 8. Nota metodológica

La metodología de mapeo a ATT&CK, con sus dos rutas y sus reglas de abstención, está en la documentación del proyecto. Ningún dato aparece en este informe sin una fuente identificable y sin un nivel de confianza declarado.

### Estado de recolección por fuente

| Fuente | Estado | Registros | Inválidos | No soportados | Cobertura evaluada |
|---|---|---|---|---|---|
| `cisa-kev` | correcta | 1656 | 0 | 0 | sí |
| `threatfox` | correcta | 5712 | 0 | 0 | sí |

### Catálogo ATT&CK

- **Versión del bundle:** 19.1
- **Digest:** `a6c366439edee3a87b79cf90dc0b93f5d7975956`
- **Procedencia:** descarga
- **Objetos Software indexados:** 821 (3 excluidos por revocados o deprecados)
- **Canons distintos:** 1096
- **Canons ambiguos:** 2 — coincide con la línea base declarada del catálogo
- **Cambio respecto a la ejecución anterior:** no se puede declarar todavía. El estado no persiste la versión ni el digest usados la vez anterior, de modo que este informe no sabe si el catálogo cambió. Es una laguna declarada, no un «no cambió»: un cambio de catálogo puede hacer aparecer o desaparecer un mapeo sin que la amenaza se haya movido.

### Motivos de mapeo ausente, cada uno a su nivel

**Nivel familia** — denominador: **89 familias observadas**.

- `ambiguedad_candidatos`: 1 de 89 familias
- `familia_sin_entrada`: 67 de 89 familias

**Nivel indicador** — denominador: **5712 indicadores de ThreatFox**.

- `sin_atribucion`: 544 de 5712

**Nivel entrada KEV** — denominador: **1656 entradas KEV procesadas**.

- `producto_inespecifico`: 129 de 1656
- `producto_sin_clasificar`: 1008 de 1656


### Cobertura de la tabla de vectores de explotación

Medida sobre las **1656 entradas KEV procesadas** en esta ejecución (2026-07-29), no proyectada:

- **Con vector inferido:** 519 (31%)
- **Sin clasificar** (trabajo pendiente, alimenta la cola de abajo): 1008 (60%)
- **Producto inespecífico** (no es trabajo pendiente: no puede clasificarse por la vía del par fabricante-producto): 129 (7%)

Las dos últimas no se suman: una mide lo que falta por curar y la otra lo que no puede curarse así. Confundirlas dejaría la cobertura con un suelo que nunca se alcanza.

### Cola de trabajo: entradas KEV **vigentes del catálogo** sin clasificar

Se publica la **cabecera** de la cola: las primeras 20 de **1008** entradas sin clasificar en el catálogo completo. Una lista de mil no es una cola de trabajo.

Ordenada por valor de decisión —uso en ransomware primero, fecha límite después—, no alfabéticamente ni por frecuencia.

| CVE | Fabricante | Producto | Ransomware | Fecha límite |
|---|---|---|---|---|
| `CVE-2021-1675` | Microsoft | Windows | Known | 2021-11-17 |
| `CVE-2021-20016` | SonicWall | SSLVPN SMA100 | Known | 2021-11-17 |
| `CVE-2021-22205` | GitLab | Community and Enterprise Editions | Known | 2021-11-17 |
| `CVE-2021-22986` | F5 | BIG-IP and BIG-IQ Centralized Management | Known | 2021-11-17 |
| `CVE-2021-26084` | Atlassian | Confluence Server and Data Center | Known | 2021-11-17 |
| `CVE-2021-35211` | SolarWinds | Serv-U | Known | 2021-11-17 |
| `CVE-2021-35464` | ForgeRock | Access Management (AM) | Known | 2021-11-17 |
| `CVE-2021-36942` | Microsoft | Windows | Known | 2021-11-17 |
| `CVE-2021-36955` | Microsoft | Windows | Known | 2021-11-17 |
| `CVE-2021-38647` | Microsoft | Open Management Infrastructure (OMI) | Known | 2021-11-17 |
| `CVE-2021-40444` | Microsoft | MSHTML | Known | 2021-11-17 |
| `CVE-2021-40539` | Zoho | ManageEngine | Known | 2021-11-17 |
| `CVE-2021-41773` | Apache | HTTP Server | Known | 2021-11-17 |
| `CVE-2021-42013` | Apache | HTTP Server | Known | 2021-11-17 |
| `CVE-2021-42258` | BQE | BillQuick Web Suite | Known | 2021-11-17 |
| `CVE-2021-40449` | Microsoft | Windows | Known | 2021-12-01 |
| `CVE-2021-42321` | Microsoft | Exchange | Known | 2021-12-01 |
| `CVE-2021-40438` | Apache | Apache | Known | 2021-12-15 |
| `CVE-2021-44228` | Apache | Log4j2 | Known | 2021-12-24 |
| `CVE-2021-43890` | Microsoft | Windows | Known | 2021-12-29 |

**Parte de esta cola no es atendible por esta vía**, y se declara: las entradas cuyo par (fabricante, producto) no determina por sí solo la clase de vector —un sistema operativo completo, el nombre de una suite— no pueden curarse con la tabla de pares, y nadie las curará así. No se cuantifica: medirlo exigiría una clasificación que hoy no existe.
